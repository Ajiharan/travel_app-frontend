import React from "react";

const AdminHome = () => {

  return (
    <div className="login-form">
      <h1 className="heading">AdminHome</h1>
      <p className="lead">
        <i className="fas fa-user"></i>
        AdminHome
      </p>
      <br />
    </div>
  );
};

export default AdminHome;
